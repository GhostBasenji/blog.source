---
type: 'balloon'
balloon_img_src: "icons/vase.svg"
balloon_img_src_dark: "icons/vase_dark.svg"
balloon_circle: false
balloon_resources: "/about"
description: "Demo site of hugo-theme-monochrome"
zooming_js: false
keywords:
- hugo
- hugo theme
- hugo theme monochrome
- clean
- responsive
- programmer-friendly
---

{{< icon vendor="feather" name="github" link="https://github.com/kaiiiz/hugo-theme-monochrome" >}}

This is the demo of hugo-theme-monochrome.
