---
title: 'Acknowledgement'
weight: 1000
gallery_img_src: 'thanks.jpg'
gallery_img_caption: '<span>Photo by <a href="https://unsplash.com/@swimstaralex?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Alexander Sinn</a> on <a href="https://unsplash.com/s/photos/thanks?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></span>'
gallery_statistic:
- key: '**key1**'
  value: '*value1*'
- key: '**key2**'
  value: '*value2*'
- key: '**key3**'
  value: '*value3*'
---

* [PrismJS/prism](https://github.com/PrismJS/prism) MIT
* [leeoniya/uFuzzy](https://github.com/leeoniya/uFuzzy) MIT
* [mathjax/MathJax](https://github.com/mathjax/MathJax) Apache-2.0
* [kingdido999/zooming](https://github.com/kingdido999/zooming) MIT
* [feathericons/feather](https://github.com/feathericons/feather) MIT
* [simple-icons/simple-icons](https://github.com/simple-icons/simple-icons) CC0-1.0
