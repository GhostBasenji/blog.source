---
title: 'Timeline'
weight: 2
gallery_img_src: 'clock.jpg'
gallery_img_caption: '<span>Photo by <a href="https://unsplash.com/@oceanng?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Ocean Ng</a> on <a href="https://unsplash.com/s/photos/clock?utm_source=unsplash&amp;utm_medium=referral&amp;utm_content=creditCopyText">Unsplash</a></span>'
gallery_statistic:
- key: '**key1**'
  value: '*value1*'
- key: '**key2**'
  value: '*value2*'
- key: '**key3**'
  value: '*value3*'
---

* 2025/10/26 - v5.2.3 release
* 2025/10/26 - v5.2.2 release
* 2025/10/26 - v5.2.1 release
* 2025/10/26 - v5.2.0 release
* 2025/07/08 - v5.1.0 release
* 2025/07/06 - v5.0.0 release
* 2024/11/27 - v4.0.0 release
* 2024/05/26 - v3.1.0 release
* 2024/05/26 - v3.0.0 release
* 2023/07/23 - v2.0.0 release
* 2022/04/02 - v1.0.1 release
* 2022/04/01 - v1.0.0 release
* 2022/02/25 - v0.9.2 release
* 2022/02/25 - v0.9.1 release
* 2022/01/31 - v0.9.0 release
* 2021/07/29 - v0.8.0 release
* 2021/07/08 - v0.7.1 release
* 2021/06/24 - v0.7.0 release
* 2021/04/15 - v0.6.2 release
* 2021/02/17 - v0.6.1 release
* 2021/02/16 - v0.6.0 release
* 2021/02/15 - v0.5.0 release
* 2021/02/12 - v0.4.0 release
* 2021/02/10 - v0.3.0 release
* 2021/02/09 - v0.2.0 release
* 2021/02/08 - v0.1.0 release
