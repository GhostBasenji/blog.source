---
title: 'Configuration'
type: 'bookcase'
---

These documents show some customizable values that are used in this theme. By adjusting these values, you can easily change the behavior of your website without touching the source code.

You can refer to the example config in [github](https://github.com/kaiiiz/hugo-theme-monochrome/tree/main/exampleSite/config).
