---
title: 'Layouts'
type: 'bookcase'
---

Monochrome has multiple layouts built in. You can change the layout of section or regular page according to your needs.
