---
title: 'Balloon Layout'
bookcase_cover_src: 'cover/balloon.png'
bookcase_cover_src_dark: 'cover/balloon_dark.png'
type: "bookcase"
---

Balloon layout is useful for demonstrating information step-by-step.

> This layout can be used on both section page (`_index.md`) and regular post (`xxx.md`).
