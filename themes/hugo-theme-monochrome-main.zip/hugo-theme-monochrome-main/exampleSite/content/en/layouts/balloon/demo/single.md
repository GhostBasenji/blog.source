---
title: 'balloon layout single demo'
type: 'balloon'
balloon_img_src: "icons/balloon.svg"
balloon_img_src_dark: "icons/balloon_dark.svg"
balloon_circle: false
balloon_resources: "/about"
---

Balloon layout can also be used in regular page.

[Go to list demo](/hugo-theme-monochrome/layouts/balloon/demo)
