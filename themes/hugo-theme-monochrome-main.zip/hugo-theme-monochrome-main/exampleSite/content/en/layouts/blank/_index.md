---
title: 'Blank Layout'
bookcase_cover_src: 'cover/coding.png'
bookcase_cover_src_dark: 'cover/coding_dark.png'
type: "bookcase"
---

Sometimes, it's useful to fully control your section page, so I create a layout with only render the `_index.md` content and called this Blank Layout.

> This layout can only be used on section page (`_index.md`).
