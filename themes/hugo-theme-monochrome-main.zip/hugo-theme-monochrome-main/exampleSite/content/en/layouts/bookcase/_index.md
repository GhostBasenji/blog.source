---
title: 'Bookcase Layout'
bookcase_cover_src: 'cover/bookcase.png'
bookcase_cover_src_dark: 'cover/bookcase_dark.png'
type: "bookcase"
---

Bookcase layout is useful for creating another viewpoint of list contents.

> This layout can only be used on section page (`_index.md`).
