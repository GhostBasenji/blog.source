---
title: 'List'
bookcase_cover_src: 'cover/list.png'
bookcase_cover_src_dark: 'cover/list_dark.png'
---

List section in bookcase layout.
