---
title: 'Regular Page'
bookcase_cover_src: 'cover/catalogue.png'
bookcase_cover_src_dark: 'cover/catalogue_dark.png'
---

This is a regular page in bookcase.
