---
title: 'Gallery Layout'
bookcase_cover_src: 'cover/picture.png'
bookcase_cover_src_dark: 'cover/picture_dark.png'
type: "bookcase"
---

Gallery layout is useful for demonstrating pictures and its statistical data.

> This layout can be used on both section page (`_index.md`) and regular post (`xxx.md`).
