---
title: 'Gallery Layout Demo'
type: 'gallery'
gallery_resources: "about"
bookcase_cover_src: 'cover/picture.png'
bookcase_cover_src_dark: 'cover/picture_dark.png'
weight: 30
---

Gallery layout is useful for demonstrating pictures and its statistical data.
