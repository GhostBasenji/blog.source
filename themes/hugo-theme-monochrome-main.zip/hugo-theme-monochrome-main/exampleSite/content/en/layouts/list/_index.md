---
title: 'List Layout'
bookcase_cover_src: 'cover/list.png'
bookcase_cover_src_dark: 'cover/list_dark.png'
type: "bookcase"
---

List layout is the built-in section layout. Monochrome add options to adjust its behavior.
