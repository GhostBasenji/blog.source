---
title: 'List Layout Demo'
bookcase_cover_src: 'cover/list.png'
bookcase_cover_src_dark: 'cover/list_dark.png'
weight: 40
pagination: true
---

```
.
├── _index.md <- you're here!
├── post1.md
├── post2.md
├── post3.md
├── post4.md
├── post5.md
└── post6.md
```
