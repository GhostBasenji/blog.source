---
title: 'Postcard Layout'
bookcase_cover_src: 'cover/catalogue.png'
bookcase_cover_src_dark: 'cover/catalogue_dark.png'
type: "bookcase"
---

Postcard layout shows summary of regular posts, it’s useful for creating home page. Postcard layout paginates page according to your `paginate` config setting.

> This layout can only be used on section page. (`_index.md`)
