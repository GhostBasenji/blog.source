---
title: 'Postcard Layout Document'
bookcase_cover_src: 'cover/catalogue.png'
bookcase_cover_src_dark: 'cover/catalogue_dark.png'
weight: 40
changelogs:
---

Postcard layout show summary of regular posts, it's useful for creating home page.

> This layout can only be used on list layout.

## Configuration

```yaml
---
type: 'postcard'
---
```

> Specify `type` in front-matter will change the template lookup order.
