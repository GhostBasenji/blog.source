+++
aliases = ["posts", "articles", "blog", "showcase", "docs"]
title = "Posts"
author = "Hugo Authors"
tags = ["index"]
type = "postcard"
+++

Some posts from [hugoBasicExample](https://github.com/gohugoio/hugoBasicExample).
