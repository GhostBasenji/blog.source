---
title: 'Breadcrumbs'
bookcase_cover_src: 'cover/coding.png'
bookcase_cover_src_dark: 'cover/coding_dark.png'
---

# Breadcrumbs

Render breadcrumbs navigation

## Usage

```
{{</* breadcrumbs /*/>}}
```

## Examples

```html
{{</* breadcrumbs */>}}
```

{{< breadcrumbs >}}
