---
title: 'JSFiddle'
bookcase_cover_src: 'cover/coding.png'
bookcase_cover_src_dark: 'cover/coding_dark.png'
---

# JSFiddle

Embedded jsfiddle to page.

## Usage

```
{{</* jsfiddle id="" */>}}
```

Parameters:

* `id`: jsfiddle id

## Examples

```html
{{</* jsfiddle id="5byh90rz" */>}}
```

{{< jsfiddle id="5byh90rz" >}}
