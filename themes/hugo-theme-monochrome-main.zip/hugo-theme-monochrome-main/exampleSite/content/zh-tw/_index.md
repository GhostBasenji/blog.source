---
---

{{< icon vendor="feather" name="github" link="https://github.com/kaiiiz/hugo-theme-monochrome" >}}

This is the demo of multilingual capability of hugo-theme-monochrome.
